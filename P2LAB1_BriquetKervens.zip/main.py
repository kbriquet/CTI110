mileage = float(input())
gas_cost = float(input())

distance1 = 20
distance2 = 75
distance3 = 500

cost1 = distance1 / mileage * gas_cost
cost2 = distance2 / mileage * gas_cost
cost3 = distance3 / mileage * gas_cost

print(f'{cost1:.2f} {cost2:.2f} {cost3:.2f}')
